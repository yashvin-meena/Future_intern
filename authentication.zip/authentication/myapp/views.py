from django.shortcuts import render, HttpResponse, redirect
from .forms import SignupForm, User, LoginForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def userRegistration(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            # uname = form.cleaned_data['username']
            # fname = form.cleaned_data['first_name']
            # lname = form.cleaned_data['last_name']
            # uemail = form.cleaned_data['email']
            # user_obj = User(
            #     username = uname,
            #     first_name = fname,
            #     last_name = lname,
            #     email = uemail,
            #     )
            # user_obj.save()
            form.save()
            messages.success(request, 'Registered successfully !!')
            return redirect('/')
        return render(request,'myapp/signup.html',locals())

    else:
        form = SignupForm()
        return render(request,'myapp/signup.html',locals())
 
def userLogin(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = LoginForm(request=request, data=request.POST)
            if form.is_valid():
                username = form.cleaned_data['username']
                password = form.cleaned_data['password']
                user = authenticate(username=username, password=password)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Login Successfully !!')
                    return redirect('/home')
            else:
                return render(request,'myapp/signin.html',locals())
        form = LoginForm()
        return render(request,'myapp/signin.html',locals())
    else:
        return redirect('/home')
    
@login_required 
def userLogout(request):
    logout(request)
    return redirect('/')

@login_required 
def home(request):
    return render(request,'myapp/home.html')

