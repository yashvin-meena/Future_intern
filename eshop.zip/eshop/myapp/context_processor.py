from . models import Cart

def count_cart_item(request):
    if request.user.is_authenticated:
        cart_count = Cart.objects.filter(user=request.user).count()
        return {'cart_count': cart_count}
    return {'cart_count': 0}