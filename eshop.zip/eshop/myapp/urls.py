from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.UserSignup.as_view(), name='signup'),
    path('login/', views.userLogin, name='login'),
    path('logout/', views.userLogout, name='logout'),
    path('password/', views.ChangePassword.as_view(), name='password'),
    path('', views.home, name='home'),
    path('shop/', views.shop, name='shop'),
    path('search', views.searchProduct, name='search'),
    path('detail/<int:id>', views.productDetail, name='detail'),
    path('category/<ch>', views.category, name='category'),
    path('addcart/', views.add_to_cart, name='addCart'),
    path('showCart/', views.showCart, name='showCart'),
    path('plusCart/', views.plusCart, name='plus'),
    path('minusCart/', views.minusCart, name='minus'),
    path('removeCart/', views.removeCart, name='remove'),
    path('profile/', views.addAddress, name='profile'),
    path('address/', views.viewAddress, name='address'),
    path('addressDelete/<int:id>', views.deleteAddress, name='addressRemove'),
    path('address-update/<int:id>', views.UpdateAddress.as_view(),name='updateAddress')
    # path('update-address/', views.UpdateAddress.as_view(), name='updateAddress')                                                                                                                                                              >')

]