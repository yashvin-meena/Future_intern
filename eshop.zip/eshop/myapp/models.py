from django.db import models
from django.contrib.auth.models import User

CATEGORY_CHOICES = [
    ('shirt','Shirt'),
    ('tshirt','T-shirt'),
    ('jeans','Jeans'),
    ('shorts','Shorts'),
    ('nightwear','Night-Wear'),
    ('formal','Formal'),
    ('partywear','Party-Wear')
]


STATE_CHOICE = (
    ('Andaman & Nicobar Islands','Andaman & Nicobar Islands'),
    ('Andhra Pradesh','Andhra Pradesh'),
    ('Arunachal Pradesh','Arunachal Pradesh'),
    ('Assam','Assam'),
    ('Bihar','Bihar'),
    ('Chandigarh','Chandigarh'),
    ('Chhattisgarh','Chhattisgarh'),
    ('Delhi','Delhi'),
    ('Goa','Goa'),
    ('Gujrat','Gujrat'),
    ('Madhya Pradesh','Madhya Pradesh'),
    ('Uttar Pradesh','Uttar Pradesh'),
    ('Rajasthan','Rajasthan')
)

class Product(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    selling_price = models.FloatField()
    discount_price = models.FloatField()
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=20)
    product_img = models.ImageField(upload_to='product')

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

class Address(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    locality = models.CharField(max_length=100)
    landmark =  models.CharField(max_length=100)
    state =  models.CharField(choices=STATE_CHOICE,max_length=50)
    mobile = models.IntegerField()
    zipcode = models.IntegerField()