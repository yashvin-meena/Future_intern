from django.shortcuts import render, redirect
from .models import Product, Cart, Address
from .forms import AddressForm, LoginForm, SignupForm, PasswordForm
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.http import JsonResponse
from django.urls import reverse
from django.contrib import messages
from django.views.generic.base import View
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin

class UserSignup(View):
    def get(self, request):
        form = SignupForm()
        return render(request, 'myapp/signup.html',{'form':form})
    
    def post(self, request):
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Account Created !!')
            return redirect('/login')
        return render(request, 'myapp/signup.html',{'form':form})

def userLogin(request):
   if not request.user.is_authenticated:
        if request.method == 'POST':
            form = LoginForm(request=request,data=request.POST)
            if form.is_valid():
                username = form.cleaned_data['username']
                password = form.cleaned_data['password']
                user = authenticate(username=username, password=password)
                if user is not None:
                    login(request,user)
                    return redirect('/')
            context = {'form': form}
            return render(request,'myapp/login.html',context)
        form = LoginForm()
        context = {'form': form}
        return render(request,'myapp/login.html',context)
   else:
       return redirect('/')

def userLogout(request):
    logout(request)
    return redirect('login')

class ChangePassword(View):
    def get(self, request):
        form = PasswordForm(user=request.user)
        context = {
            'form':form
        }
        return render(request,'myapp/password.html',context)
    
    def post(self, request):
        form = PasswordForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request,form.user)
            messages.success(request,'Password Changed')
            return redirect('/password')
        return render(request,'myapp/password.html',{'form':form})

def home(request):
    products = Product.objects.all()[:12]
    if request.user.is_authenticated:
        cart_items = Cart.objects.filter(user=request.user)
        cart_pid = cart_items.values_list('product_id',flat=True)  
        context = {
            'products': products,
            'cart_pid': cart_pid
        }
        return render(request,'myapp/home.html',context)
    context = {'products': products}
    return render(request,'myapp/home.html',context)

def searchProduct(request):
    value = request.GET.get('search',None)
    if value != (None or '' ):
        serach_item = Product.objects.filter(title__icontains = value)
        context = {'products': serach_item}
        return render(request,'myapp/category.html', context)
    return redirect('/')

def shop(request):
    products = Product.objects.order_by('?')
    if request.user.is_authenticated:
        cart_items = Cart.objects.filter(user=request.user)
        cart_pid = cart_items.values_list('product_id',flat=True)
        context = {
            'products': products,
            'cart_pid': cart_pid
        }
    else:
        context = {'products': products}
    return render(request,'myapp/shop.html',context)

def productDetail(request, id):
    p_detail = Product.objects.get(pk=id)
    if request.user.is_authenticated:
        cart_items = Cart.objects.filter(user=request.user)
        cart_pid = cart_items.values_list('product_id',flat=True)
        context = {
            'product' : p_detail,
            'cart_pid': cart_pid
        }
    else:
        context = {'product' : p_detail}
    return render(request,'myapp/detail.html', context)

def category(request,ch):
    products = Product.objects.filter(category=ch)
    if request.user.is_authenticated:
        cart_items = Cart.objects.filter(user=request.user)
        cart_pid = cart_items.values_list('product_id',flat=True)
        context = {
            'products': products,
            'cart_pid': cart_pid
        }
    else:
        context = {'products': products}
    return render(request,'myapp/category.html',context)

@login_required
def add_to_cart(request):
    if request.method == 'GET':
        pid = request.GET.get('productID')
        product = Product.objects.get(pk=pid)
        if product:
            user = request.user
            cart_item, created = Cart.objects.get_or_create(user=user, product=product)
            print(cart_item, created)
            if not created:
                    cart_items = Cart.objects.filter(user=request.user)
                    cart_count = cart_items.count()
                    return JsonResponse({'cart_count':cart_count})
            cart_item.save()
            cart_items = Cart.objects.filter(user=request.user)
            cart_count = cart_items.count()
    return JsonResponse({'cart_count':cart_count})

@login_required
def showCart(request):
    cart_items = Cart.objects.filter(user=request.user)
    amount = 0
    for item in cart_items:
         amount += (item.quantity * item.product.selling_price)
    shipping = 50
    totalAmount = amount + shipping
    context = {
        'cartitems':cart_items,
        'amount': amount,
        'shipping': shipping,
        'totalAmount': totalAmount
    }
    return render(request,'myapp/cart.html', context)

@login_required
def plusCart(request):
    if request.method == 'GET':
        pid = request.GET.get('productID')
        cart_item = Cart.objects.get(product=pid, user=request.user)
        cart_item.quantity += 1
        cart_item.save()
        cart_items = Cart.objects.filter(user=request.user)
        amount = 0
        shipping = 50
        for item in cart_items:
            amount += (item.quantity * item.product.selling_price)
        totalAmount = amount + shipping
        data = {
            'quantity': cart_item.quantity,
            'amount': amount,
            'totalAmount': totalAmount
        } 
    return JsonResponse(data)

@login_required
def minusCart(request):
    if request.method == 'GET':
        pid = request.GET.get('productID')
        cart_item = Cart.objects.get(product=pid, user=request.user)
        cart_item.quantity -= 1
        cart_item.save()
        cart_items = Cart.objects.filter(user=request.user)
        amount = 0
        shipping = 50
        for item in cart_items:
            amount += (item.quantity * item.product.selling_price)
        totalAmount = amount + shipping
        data = {
            'quantity': cart_item.quantity,
            'amount': amount,
            'totalAmount': totalAmount
        } 
    return JsonResponse(data)

@login_required
def removeCart(request):
    if request.method == 'GET':
        pid = request.GET.get('productID')
        cart_item = Cart.objects.get(product=pid, user=request.user)
        cart_item.delete()
        cart_items = Cart.objects.filter(user=request.user)
        cart_count = cart_items.count()
        amount = 0
        shipping = 50
        for item in cart_items:
            amount += item.product.selling_price
        totalAmount = amount + shipping

        shopurl = reverse('shop')

        data = {
            'amount': amount,
            'totalAmount': totalAmount,
            'cart_count': cart_count,
            'shop_url': shopurl
        } 
    return JsonResponse(data)

@login_required
def addAddress(request):
    if request.method == 'POST':
        form = AddressForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            city = form.cleaned_data['city']
            locality = form.cleaned_data['locality']
            landmark = form.cleaned_data['landmark']
            state = form.cleaned_data['state']
            mobile = form.cleaned_data['mobile']
            zipcode = form.cleaned_data['zipcode']
            data = Address(
                user = request.user,
                name = name,
                city = city,
                locality = locality,
                landmark = landmark,
                state = state,
                mobile = mobile,
                zipcode = zipcode
            )
            data.save()
            messages.success(request,' Address Added !!')
            return render(request,'myapp/profile.html',{'form':form})
        return render(request,'myapp/profile.html',{'form':form})
        
    form = AddressForm()
    context = {
        'form': form
    }
    return render(request,'myapp/profile.html',context)
@login_required
def viewAddress(request):
    address = Address.objects.filter(user=request.user)
    context = {
        'addresses': address
    }
    return render(request,'myapp/address.html', context)


class UpdateAddress(LoginRequiredMixin,View):
    def get(self, request, id):
        address = Address.objects.get(pk=id)
        form = AddressForm(instance=address)
        context = {
            'form': form
        }
        return render(request,'myapp/address_update.html',context)
    
    def post(self, request, id):
        address = Address.objects.get(pk=id)
        form = AddressForm(instance=address, data=request.POST)
        if form.is_valid():
            form.save()
            messages.warning(request,' Address updated !!')
            return redirect('/address')
        context = {
            'form': form
        }
        return render(request,'myapp/address_update.html',context)

@login_required
def deleteAddress(request, id):
    address = Address.objects.get(pk=id)
    address.delete()
    messages.warning(request,' Address deleted !!')
    return redirect('/address')