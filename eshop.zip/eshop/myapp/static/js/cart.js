$(document).ready(function(){
    $(document).on('click', '#addToCart',function(){
        let p_id = $(this).attr('pid')
        let mybtn = $(this).addClass('cart-btn')
        $.ajax({
            type: "GET",
            url: "/addcart",
            data: {
                'productID': p_id
            },

            success:function(data){
                mybtn.text('Added')
                document.querySelector('#cart-count').innerText = data.cart_count
            }
        })
    })
})


$(document).ready(function(){
    $(document).on('click','#plus-cart',function(){
        let p_id = $(this).attr('Pid')
        let element = this.parentNode.children[2]
        $.ajax({
            type: "GET",
            url: "/plusCart",
            data: {
                'productID': p_id
            },

            success: function(data)
            {
                element.innerText = data.quantity
                document.querySelector('#amount').innerText = 'Rs.'+data.amount+'.0'
                document.querySelector('#totalAmount').innerText = 'Rs.'+data.totalAmount+'.0'
                
            }
        });        
    });
})

$(document).ready(function(){
    $(document).on('click','#minus-cart',function(){
        let p_id = $(this).attr('Pid')
        let element = this.parentNode.children[2]
        $.ajax({
            type: "GET",
            url: "/minusCart",
            data: {
                'productID': p_id
            },

            success: function(data)
            {
                element.innerText = data.quantity
                document.querySelector('#amount').innerText = 'Rs.'+data.amount+'.0'
                document.querySelector('#totalAmount').innerText = 'Rs.'+data.totalAmount+'.0'
                
            }
        });        
    });
})

$(document).ready(function(){
    $(document).on('click','#remove-cart',function(){
        let p_id = $(this).attr('Pid')
        let element = $(this).closest('.card-container')

        $.ajax({
            type: "GET",
            url: "/removeCart",
            data: {
                'productID': p_id
            },
            success: function(data)
            {
                console.log(data);
                document.querySelector('#amount').innerText = 'Rs.'+data.amount+'.0'
                document.querySelector('#totalAmount').innerText = 'Rs.'+data.totalAmount+'.0'
                document.querySelector('#cart-count').innerText = data.cart_count
                element.remove();

                if ($('#cart-box .card-container').length === 0){
                    console.log(data.shop_url)
                    $('#cart-amount').hide();
                    $('#cart-box').html(`
                        <div class="text-center">
                            <p class="display-3">Cart is Empty</p>
                            <a href="${data.shop_url}" class="btn btn-primary">Add Item</a>
                        </div>
                        `)

                }
            }
        });        
    });
})
