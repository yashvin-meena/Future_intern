from django.contrib import admin
from .models import Product, Cart, Address
# Register your models here.

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id','title','selling_price']

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ['user','product','quantity']

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ['user','name','city']

