from django.db import models

class Employee(models.Model):
    emp_id = models.IntegerField()
    name = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    joining_date = models.DateField()
    sallary = models.FloatField()
