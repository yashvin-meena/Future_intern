from django.shortcuts import render, redirect
from .models import Employee
from .forms import EmployeeForm, LoginForm, SignupForm
from django.contrib.auth import login, authenticate, logout
from django.views.generic.base import View
from django.contrib import messages
from django.views.generic import DeleteView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin

def userRegistration(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Registered successfully !!')
            return redirect('/')
        return render(request,'emp/signup.html',locals())

    else:
        form = SignupForm()
        return render(request,'emp/signup.html',locals())

def userLogin(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = LoginForm(request=request, data=request.POST)
            if form.is_valid():
                username = form.cleaned_data['username']
                password = form.cleaned_data['password']
                user = authenticate(username=username, password=password)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Login Successfully !!')
                    return redirect('/')
            else:
                return render(request,'emp/login.html',locals())
        form = LoginForm()
        return render(request,'emp/login.html',locals())
    else:
        return redirect('/')
    
@login_required    
def userLogout(request):
    logout(request)
    return redirect('/login')


class AddEmployee(LoginRequiredMixin,View):
    def get(self, request):
        form = EmployeeForm()
        context = {'form':form}
        return render(request, 'emp/index.html',context)

    def post(self, request):
        form = EmployeeForm(request.POST)
        if form.is_valid():
            eid = form.cleaned_data['emp_id']
            ename = form.cleaned_data['name']
            department = form.cleaned_data['department']
            designation = form.cleaned_data['designation']
            address = form.cleaned_data['city']
            joined = form.cleaned_data['joining_date']
            sallary = form.cleaned_data['sallary']
            emp_record = Employee(
                emp_id = eid,
                name = ename,
                department = department,
                designation = designation,
                city = address,
                joining_date = joined,
                sallary = sallary,
            )
            emp_record.save()
            messages.success(request,'Employee Added !!')
            form = EmployeeForm()
        context = {'form':form}
        return render(request, 'emp/index.html',context)

@login_required 
def employee_list(request):
    employees = Employee.objects.all()
    context = {
        'employees': employees
    }
    return render(request,'emp/emp_list.html',context)

@login_required 
def employee_detail(request, id):
    emp_record = Employee.objects.get(pk=id)
    context = {
        'employee': emp_record
    }
    return render(request, 'emp/emp_detail.html', context)


class EmployeeDelete(LoginRequiredMixin,DeleteView):
    model = Employee
    template_name = 'emp/emp_confirm.html'
    success_url = '/emplist/'


class EmployeeUpdate(LoginRequiredMixin,View):
    def get(self, request, id):
        data = Employee.objects.get(pk=id)
        form = EmployeeForm(instance=data)
        context = {
          'form': form
        }
        return render(request, 'emp/emp_update.html', context)
    
    def post(self, request, id):
        data = Employee.objects.get(pk=id)
        form = EmployeeForm(request.POST, instance=data)
        if form.is_valid():
            form.save()
            messages.info(request, 'Updated !!')
            return redirect(f'/empdetail/{id}')

        context = {
          'form': form
        }
        return render(request, 'emp/emp_update.html', context)
