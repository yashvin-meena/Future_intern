from django import forms
from . models import Employee
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm, UsernameField, UserCreationForm

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'
        exclude = ['id']
        widgets = {
            'emp_id': forms.NumberInput(attrs={'class':'form-control','placeholder':'Emp_ID'}),
            'name': forms.TextInput(attrs={'class':'form-control','placeholder':'Emp_Name'}),
            'designation': forms.TextInput(attrs={'class':'form-control','placeholder':'Designation'}),
            'department': forms.TextInput(attrs={'class':'form-control','placeholder':'Department'}),
            'city': forms.TextInput(attrs={'class':'form-control','placeholder':'City'}),
            'joining_date': forms.DateInput(attrs={'class':'form-control','placeholder':'Joining_Date','type':'date'}),
            'sallary': forms.NumberInput(attrs={'class':'form-control','placeholder':'Sallary'}),
                    
        }

class SignupForm(UserCreationForm):
    password1 = forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2 = forms.CharField(label="Confirm password",widget=forms.PasswordInput(attrs={'class':'form-control'}))

    class Meta:
        model = User
        fields = ['username','first_name','last_name','email']
        widgets = {
            'username': forms.TextInput(attrs={'class':'form-control'}),
            'first_name': forms.TextInput(attrs={'class':'form-control'}),
            'last_name': forms.TextInput(attrs={'class':'form-control'}),
            'email': forms.EmailInput(attrs={'class':"form-control"})
        }


class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={'class':"form-control",'placeholder':'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}))
