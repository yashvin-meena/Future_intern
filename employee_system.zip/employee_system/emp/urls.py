from django.urls import path
from . import views
urlpatterns = [
    path('register/', views.userRegistration, name='register'),
    path('login/', views.userLogin, name='login'),
    path('logout/', views.userLogout, name='logout'),
    path('', views.AddEmployee.as_view(), name='add'),
    path('emplist/', views.employee_list, name='list'),
    path('empdetail/<int:id>', views.employee_detail, name='detail'),
    path('empdelete/<int:pk>', views.EmployeeDelete.as_view(), name='delete'),
     path('empupdate/<int:id>', views.EmployeeUpdate.as_view(), name='update'),
]